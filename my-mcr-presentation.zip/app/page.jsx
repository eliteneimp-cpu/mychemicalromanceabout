'use client';
export default function Page(){
  return (
    <div style={{padding:40}}>
      <h1>My Chemical Romance Presentation</h1>
      <p>Includes two album covers.</p>
      <img src="/images/bullets.jpg" width="300"/>
      <img src="/images/threecheers.jpg" width="300"/>
    </div>
  );
}
