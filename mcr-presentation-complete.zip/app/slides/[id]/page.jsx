
'use client';
import { useParams } from 'next/navigation';
import '../../globals.css';

const slides = [["Portada", "My Chemical Romance (MCR) es una banda de rock...", "/images/bullets.jpg"], ["Historia", "Fundada en 2001 por Gerard Way...", "/images/bullets.jpg"], ["Three Cheers", "\u00c1lbum que llev\u00f3 a MCR a la fama global...", "/images/threecheers.jpg"], ["Otros Discos", "I Brought You My Bullets... Conventional Weapons...", "/images/bullets.jpg"], ["Canciones Indispensables", "I'm Not Okay, Helena, Welcome to the Black Parade...", "/images/threecheers.jpg"]];

export default function SlidePage() {
  const params = useParams();
  const id = parseInt(params.id);
  const slide = slides[id] || slides[0];

  return (
    <div>
      <h1>{slide[0]}</h1>
      <p>{slide[1]}</p>
      <img src={slide[2]} width="300" />
      <div style={ {'marginTop':20} }>
        {id>0 ? <a href={`/slides/${id-1}`}>← Anterior</a> : null}
         | 
        {id<slides.length-1 ? <a href={`/slides/${id+1}`}>Siguiente →</a> : null}
      </div>
    </div>
  );
}
